package docker

const (
	// DockerEndpoint is the name of the docker endpoint in a stored context
	DockerEndpoint = "docker"
)
