package commandconn

import (
	"os/exec"
)

func createSession(cmd *exec.Cmd) {
}
